#diconsole
This project is creating console app for CMTTCH
This line is added by buidanhquy
