#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "userver.h"
#include "ansi-utils.h"

volatile int oiu_id, riu_id;

void usage(char *app) {
	printf("%s <connection string>\n", app);
	exit(-1);
}

static void parsed_request(char *buff, int len, uproto_request_t *req) {
	char username [50];
	int acc_id;
	int ret_code;
	sscanf(buff, "{acc_id:%d ,code:%d ,username:%s }", &acc_id, &ret_code, username);
	req->ret_code = ret_code;
	req->acc_id = acc_id;
	strncpy(req->username, username, sizeof(req->username));
}

static void on_request(userver_t *userver, uproto_request_t *request, uproto_response_t *response) {
	// Do nothing, just generate a response
	response->code = 1;
	strncpy(response->msg, "Received!", sizeof(response->msg));

	char string_acc_id[5];
	sprintf(string_acc_id, "%d", request->acc_id);
	strcpy(userver->oiu.id, "oiu_user_");
	strcat(userver->oiu.id, string_acc_id);
	oiu_id ++;
	if (request->ret_code == 1) // need more condition
		userver->oiu.is_online  = 1;
	else 
		userver->oiu.is_online = 0;
	strncpy(userver->oiu.user_id, request->username, sizeof(userver->oiu.user_id));
	oius_append(&userver->o_head, &userver->oiu);
}

static int build_response(char *buff, int len, uproto_response_t *response) {
	return snprintf(buff, len, "{code:%d, msg:%s }", response->code, response->msg);
}

int main(int argc, char *argv[]) {
	userver_t userver;
	char option[10];

	if( argc < 2 ) {
		usage(argv[0]);
	}

	oiu_id = 0;
	riu_id = 0;

	userver_init(&userver, argv[1]);
	
	userver.parse_request_f = &parsed_request;
	userver.build_response_f = &build_response;
	userver.on_request = &on_request;

	oius_init(&userver.o_head);
//	rius_init(&userver.r_head);

	userver_start(&userver);

	while(1) {
		if (fgets(option, sizeof(option), stdin) == NULL ) {
			puts("NULL command\n");
		}
		switch(option[0]) {
			case 'm':
				DL_FOREACH(userver.o_head, userver.o_node) {
					printf("Node: id=%s, is_online=%d,user_id=%s\n", userver.o_node->id, userver.o_node->is_online, userver.o_node->user_id);
				}
				break;
			default:
				break;
		}
	}
	// Main loop goes here
	userver_end(&userver);

	return 0;
}
